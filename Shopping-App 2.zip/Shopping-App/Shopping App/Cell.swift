//
//  Cell.swift
//  Shopping App
//
//

import UIKit

class Cell: UICollectionViewCell {
    
    @IBOutlet var imageView: UIImageView!
    
    @IBOutlet var label: UILabel!
    
}
