//
//  SingletonManager.swift
//  Shopping App
//
//

import Foundation

class ModelHelper
{
    static let model = Model()
}
